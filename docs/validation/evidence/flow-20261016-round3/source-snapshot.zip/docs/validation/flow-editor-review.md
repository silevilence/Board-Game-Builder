# 状态机可视化设计 Editor 插件验收

日期：2026-10-16（二审修复）。基线为 `4ffb163`，证据对应未提交工作树；具体源码字节见本轮来源清单。
需求来源为 ROADMAP 的引擎流程组与 Editor 可视化组。历史实施证据和本轮复验分别保存，不把历史 success JSON 当作当前版本通过证明。

## 本轮构建、回归与导出

| 验证 | 结果 | 原始证据 |
| --- | --- | --- |
| Release 全解决方案 | 0 警告、0 错误 | [构建日志](evidence/flow-20261016-round2/build.log) |
| 回归 | 32 组 PASS | [完整日志](evidence/flow-20261016-round2/regression.log) |
| 项目依赖边界 | 通过 | [边界日志](evidence/flow-20261016-round2/boundaries.log) |
| 真实流程 UI | exitCode=0，success=true | [UI 报告](evidence/flow-20261016-round2/ui.json)、[截图](evidence/flow-20261016-round2/ui.png) |
| 既有格式生命周期 | exitCode=0，success=true | [格式报告](evidence/flow-20261016-round2/formats.json) |
| 当前源码的正式独立 Player | self-contained win-x64 发布成功 | [发布日志](evidence/flow-20261016-round2/publish.log)、[发行文件哈希](evidence/flow-20261016-round2/release-manifest.json) |
| 草稿正式导出 | exitCode=0，success=true；检查草稿不保存、来源指纹、缺依赖及插件清理 | [导出报告](evidence/flow-20261016-round2/export.json) |

三个探针的退出码和本轮源码 SHA-256 共同记录在[来源报告](evidence/flow-20261016-round2/source.json)。
本轮以一次完整构建、32 组回归及三个探针采集覆盖率；没有用多轮通过次数代替日志。

`flow-delivery` 在 [FlowDeliveryTests](../../tests/Engine.Tests/FlowDeliveryTests.cs) 中实际执行
`GamePackage.Pack → Directory.Delete(source) → GameRuntime.Load(package)`，然后从包含流程内容的快照完成 CPU 对局并检查篡改拒绝。
本轮日志包含该组 PASS，因此引擎组“打包后删除原目录仍可运行”有当前测试证据，而非仅有历史 Player 报告。

## 干净 Windows 与产物身份

本轮完整宿主执行退出码为 **0**；客体核对 **571 个文件**后完成种子 71／72／73 的批量对局（重跑、回放均通过）及 **2 局 GUI 对局**，两个 Player 进程均 exitCode=0。
[客体结果](evidence/flow-20261016-round2/sandbox.json)、[无全局 .NET 的环境](evidence/flow-20261016-round2/sandbox-environment.json)、
[批量日志](evidence/flow-20261016-round2/sandbox-batch.log)、[GUI 报告](evidence/flow-20261016-round2/sandbox-player.json)、
[宿主执行记录](evidence/flow-20261016-round2/sandbox-host.json)与[导出文件清单](evidence/flow-20261016-round2/export-manifest.json)均已归档。
`game.bgm` SHA-256 为 `248e6285a6dba3c606bd85a711d86faf1de21cb66187fb14b30fb1dfb742167b`；客体返回的清单 SHA-256 为 `8a6756cb450702b89ff55ab4279903f0ba728db8ac814b1eb1547340fcbcecb8`，与宿主文件一致。

首次尝试因冷启动超过宿主的 5 分钟期限而失败，不计作完整通过。将期限改为 10 分钟后，在新的空白 Sandbox 完整复跑得到上述结果；实例随后自动关闭。
构建采集之后只有 Sandbox 启动脚本的超时与既有实例检查发生变化，生产源码哈希全部保持一致；该差异记入宿主记录，并单独归档[启动脚本](evidence/flow-20261016-round2/validate-flow-sandbox.ps1)与[客体脚本](evidence/flow-20261016-round2/validate-standalone-windows.ps1)。

验证只映射导出目录、脚本及独立证据目录，不映射作者工程；客体先复制导出游戏并核对每个文件的 SHA-256，再运行批量与 GUI 对局。
环境检查要求 dotnet 命令与 Program Files 下的全局 Runtime 均不存在。导出包含自己的 Runtime，不依赖安装 SDK。
`export-manifest.json` 绑定本轮源码报告的 SHA-256、客体验证脚本的 SHA-256 和全部导出文件；客体结果再次返回清单与 game.bgm 的 SHA-256。

## 覆盖率范围与明细

本轮 **2152/2330 行，92.36%**；[原始 Cobertura](evidence/flow-20261016-round2/coverage.xml)、
[逐文件未覆盖行及完整方法数据](evidence/flow-20261016-round2/coverage-summary.json)、
[工具信息](evidence/flow-20261016-round2/coverage-tool.json)、[含版本横幅的采集日志](evidence/flow-20261016-round2/collection.log)均归档。
工具横幅为 Microsoft.CodeCoverage.Console 18.6.0.0，文件版本为 18.600.26.16602。

采集只包含 [flow-coverage.config](../../scripts/flow-coverage.config) 的正向 Include 匹配项：
Flow 系列以及 GameEngine、Replay、PlaySession、GameRuntime、RuntimeComposition、RunOperations、ValidationOperations、DebugSession、SessionController、AuthorWorkspace、DocumentWorkspace、导出及编辑器生命周期相关文件。
FlowVerification 是显式 Exclude；RuntimeDocumentVerification、ExportVerification 等验证驱动因不匹配 Include 同样不计入生产分母。此处不声称只有一个验证驱动被排除。

[方法明细](flow-editor-coverage.md)由同一 XML 自动生成，完整列出 **86 个低于 90% 的方法条目**，包含编译器生成的回调与状态机。
这不是全仓覆盖率，也不表示每个方法达到 90%；历史 94.46% 的局部范围、上一轮 90.03% 与当前结果分别保留，不混用方法表或行号。
汇总脚本在事务、状态、回放、会话等关键文件缺失时直接失败。

## 二审意见逐条处理

14 项待处理意见中，12 项完全采纳、1 项部分采纳、1 项不采纳迁移要求；本轮无未完成的阻塞项。

| 意见 | 决策与依据 |
| --- | --- |
| Standards 5：共享节点字面量 | 完全采纳。[FlowNodeKinds](../../src/Runtime/Flow/FlowDefinition.cs#L15) 集中四类常量及只读集合；校验、工作区、运行控制器、作者创建、画布与按钮使用同一契约。标题和颜色仍归 UI。 |
| Standards 6：字符／字节混用 | 完全采纳。[Parse](../../src/Runtime/Flow/FlowDefinition.cs#L59) 按 UTF-8 字节数限制；新增 ASCII 边界与字符数未超限、字节数超限的中文输入测试。 |
| Standards 7：另两处同步等待 | 不采纳迁移要求。[ExternalWorkspace](../../src/Editor.Core/ExternalWorkspace.cs#L60) 和 [ModuleDocument](../../src/Editor.Core/ModuleDocument.cs#L107) 实际使用 DiskEditMode；本轮的 ApplyInline 属于 WorkspaceEditMode，不能用它替换磁盘保存／协调。没有宣称已消除整个编辑器全部同步等待。 |
| Standards 10：裸布尔声明 | 部分采纳。[Reach](../../src/Runtime/Flow/FlowValidation.cs#L95) 改为接受有向邻接表，移除方向布尔参数；[Evaluate](../../src/Runtime/Flow/FlowConditions.cs#L14) 的 bool? 明确表示真／假／未知，保留公开类型和兼容性，并补返回值文档。 |
| 新发现：ExportVerification 清理 | 完全采纳。[ExportVerification](../../src/Editor/ExportVerification.cs#L63) 只访问仍存在的服务；清理结束后写报告。正式导出探针退出码与报告一起验证。 |
| 新发现：脚本依赖 rg | 完全采纳。改用已有前置 Git 的文件枚举；覆盖率工具另提供 VS 安装发现及显式路径参数。 |
| 新发现：异常事件未索引 | 完全采纳。[一审异常事件](evidence/flow-20261016/ui-failed-cleanup-events.json)已加入一审采集清单，并在本文引用。 |
| 新发现：字段列表重复 | 完全采纳。DocumentWorkspace 与 AuthorWorkspace 共用 [PendingFormNames](../../src/Editor.Core/DocumentWorkspace.cs#L67)，排序与分隔符一致；测试两个拒绝入口。 |
| 新发现：ROADMAP 说明陈旧 | 完全采纳。以本轮实际结果同步原任务下的验收说明；不改写历史需求。 |
| Spec a1：排除范围措辞 | 完全采纳。明确正向 Include 和显式 Exclude 均会限制范围，汇总 JSON 同步表达。 |
| Spec c2：串行调用纪律 | 完全采纳。[FlowController](../../src/Runtime/Flow/FlowController.cs#L23) 字段旁注明 LocalGameSession 的 commands 锁及 Cancel 的独立职责；不增加冗余锁。 |
| 新声明：方法清单陈旧 | 完全采纳。删除旧局部表，使用同一 XML 生成全部未达 90% 方法及数量。 |
| 新声明：次数、构建、工具证据 | 完全采纳。本轮仅声明归档的一次完整采集；构建日志、采集日志和工具版本／哈希均可复核。 |
| 新声明：正式导出／干净 Windows 缺口 | 完全采纳。重新发布、导出并以文件哈希绑定客体验证；独立环境结果记录在上节，不使用历史 Sandbox 结论代替。 |

一审已确认正确且二审再次验证的裁决保持不变：ExitCode 由 CLI 经 IAuthorOutcome 消费；版本字段为协议元数据；
FlowPlayback 的版本匹配职责不迁移；会话故障与流程可恢复暂停分别检查；创建流程命令明确标注替换规则控制器且可撤销；
系统和玩家调用 Leave 前均已递增 Revision，轨迹编号无须修正。

## 复跑方式与前置

使用 PowerShell 7、Git、仓库 global.json 指定的 .NET SDK；真实 UI 和发行针对 Windows。
覆盖率另外需要 Microsoft.CodeCoverage.Console，可来自 Visual Studio Code Coverage 组件，不要求安装到 PATH。
干净环境复验需要已启用 Windows Sandbox，使用一个没有既有任务的空白实例。

1. `pwsh -NoProfile -File scripts/publish-player.ps1 -Output artifacts/player-flow-new`
2. `pwsh -NoProfile -File scripts/measure-flow-coverage.ps1 -Output artifacts/flow-check-new -Release artifacts/player-flow-new`
3. `pwsh -NoProfile -File scripts/validate-flow-sandbox.ps1 -ExportDirectory artifacts/flow-check-new/export-check/export -Output artifacts/flow-sandbox-new -SourceEvidence artifacts/flow-check-new/result.json`
4. `pwsh -NoProfile -File scripts/summarize-flow-coverage.ps1 -InputFile artifacts/flow-check-new/coverage.xml -OutputFile artifacts/flow-check-new/summary.json -Markdown docs/validation/flow-editor-coverage.md`

采集脚本通过 PATH 或 Visual Studio 的 vswhere 查找工具；也可传 `-CoverageTool 'C:\完整路径\Microsoft.CodeCoverage.Console.exe'`。
本机路径记录在工具信息中。只做回归/UI 时可运行 `scripts/validate-flow.ps1 -Ui -Output <新目录>`，加 `-Release <发行目录>`可同时验证导出。
所有输出目录使用新路径。覆盖率百分比、方法条数及源码行号必须取自同一次采集，不能手工延用历史表。

## 历史记录与证据边界

[历史实施清单](evidence/flow-20261016/historical-manifest.json)与[一审修复清单](evidence/flow-20261016/current-manifest.json)保留原始文件和哈希。
其中名称含 current 的文件是“一审当时”的快照，不代表二审之后的源码。
旧 FlowVerification、RuntimeDocumentVerification、ExportVerification 都可能在写出 success 后因再次访问已释放服务而异常退出；
历史 export-historical／export-complete-historical 仅有 JSON，没有退出码，不能单独证明正常退出。
旧方法表和未经完整日志支持的重复运行次数不再作为本轮证据。

本轮证据汇总在[二审清单](evidence/flow-20261016-round2/manifest.json)。捕获文件使用 Git -text 属性保留原始字节，防止换行转换破坏哈希。
首期仍为平面流程图；任意 Lua 的动态引用和终止性不做静态证明，不包含热替换图、Lua 断点、嵌套或并行状态。
