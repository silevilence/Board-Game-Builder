-- ctx: state, parameters, gameContext, nodeContext
-- Return controlled commands and a named result; never a target node ID.
return { execute = function(ctx)
  return { commands = {}, result = 'done' }
end }
