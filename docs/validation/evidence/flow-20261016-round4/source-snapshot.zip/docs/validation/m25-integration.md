# M2.5 接入验证

实施基线：`bc73d0a35e1640aedd885e66ff7f34c3e1af2159`。日期：2026-10-06。

## 版本与接入选择

用户确认直接升级 Avalonia，目标为 12.1.1，与 CordiSharp.Plugins.Avalonia 0.2.0 对齐。
CordiSharp 核心固定 0.2.0；NuGet 包元数据记录源码提交
`7b6cde4f43013ae4ff026b5f7bea5e5f9dd9300f`。
上游参考：[CordiSharp](https://github.com/oniemiddle/CordiSharp)。
本地查阅的上游 HEAD 为 `01f121728be1455101e260d69ffcc27c8599e3fa`，不将 HEAD 等同于发布包源码。

项目原 Avalonia 11.3.10 无法直接满足扩展对 12.1.1 的依赖。
保留 11.3.10 加薄 UI 适配曾作为候选，用户明确选择升级后不再沿该路径实施。
MonoGame 保持 3.8.4.1，Windows NativeControlHost 与原生视口继续复用。

SDK 固定 10.0.112，其 Roslyn 为 5.0；CordiSharp 0.2.0 附带分析器／生成器引用 Roslyn 5.6，
导致 CS9057。通过 Directory.Build.targets 精确排除这两个可选构建工具；
不降级诊断等级，不屏蔽其他分析器，插件使用显式注册／注入及运行时反射。

## 可重复验证入口

`tests/Editor.Compatibility` 是真实 Avalonia 窗口与 MonoGame 图形设备探针。
运行参数为输出 JSON 路径；包含两个有依赖的插件、三轮启停、加载失败清理、
缺失依赖等待状态以及图形设备计数。探针与正式入口使用同一 Windows 应用清单。

```powershell
dotnet restore tests/Editor.Compatibility --locked-mode
dotnet build tests/Editor.Compatibility -c Release --no-restore
./tests/Editor.Compatibility/bin/Release/net10.0-windows/Editor.Compatibility.exe artifacts/m25/compatibility.json
```

## 接入结果

升级后的 Release 全解决方案构建通过，0 警告、0 错误。
将 9 处弃用的 TextBox.Watermark 替换为 PlaceholderText，未屏蔽弃用诊断。
锁定模式还原通过。`artifacts/m25/compatibility-v12.json`：3 轮、15 个实际绘制帧、
结束时 0 个图形设备、空失败列表；包含 UI 扩展槽位注销与加载失败回滚。
正式 Editor 的 `--smoke` 探针另通过三轮视口重建和长标签纹理复用检查。
面板工厂在 RegisterSlot 前执行，使用户工厂失败不会在上游槽位目录留下半注册项。

结论：采用 Avalonia 12.1.1 + CordiSharp / CordiSharp.Plugins.Avalonia 0.2.0。
无需替换渲染管线，可进入正式编辑器迁移。后续完整工作流及发行物回归单独记录。


## 基础宿主验证

`Editor.exe --verify-foundation artifacts/m25/foundation.json` 通过：基础插件打开空模块；
可选插件初始化失败后文档实例保持不变；必需文档插件停用被明确拒绝；退出后根 fiber 副作用数为零。
正常入口已使用 EditorHost 装配基础插件。文档、草稿、会话与各功能的进一步迁移按后续任务推进。

## 依赖策略验证

`dotnet run --project tests/Engine.Tests -c Release -- cordi` 通过。
A→B→C 依赖链按反向释放、正向恢复；B 初始化失败后本次链全部回滚，独立插件保留。
三轮重载后事件仅触发一次；缺失能力显示 Waiting 及缺失名称，循环、重复能力、API 不兼容明确失败。
活动引用 guard 在任何销毁发生前检查，拒绝停用后仍保留实例；引用解除后可停用。

## 面板贡献验证

`artifacts/m25/panels.json` 通过：独立面板三轮启停、重复 ID 拒绝、第二个工厂失败时
撤销该插件已生成的第一个面板，基础设置和插件管理面板仍在。
工厂、挂载、移除与 IDisposable 清理均在 UI 线程执行，清理令牌幂等。

## 命令验证

`artifacts/m25/commands.json`：统一命令在真实按钮及 Avalonia Ctrl+F8 路由上每轮各执行一次，
禁用后按钮与注册器均拒绝执行；三轮启停无重复，注销后注册器为空。
菜单与工具栏共享 ICommand；作者快捷键避开 TextBox 和试玩视口焦点。
服务及事件由 CordiSharp 提供，导入动作使用命令接口，附加步骤使用有归属及执行租约的贡献目录。

## 文档与草稿验证

`artifacts/m25/documents.json` 通过真实配置面板重建后草稿保留、草稿 Undo/Redo、
取消离开保留状态、多入口冲突保留草稿、已应用脚本修改的 Undo/Redo 以及保存重开指纹一致。
基础文档插件拥有 ModuleDocument、草稿、Undo 与未保存选择；退出检查注册到应用关闭协调器。
JSON 与 YAML 对同一文件的并行草稿明确拒绝同时应用，不静默覆盖。

## 作者面板验证

`artifacts/m25/author-panels.json` 通过：资源树、YAML、原型、媒介、席位面板分别重启；
创建原型、实例化、更新组件后保存重开可加载，公共选择状态在面板重建后保留。
核心 documents/prototypes/media/layouts/medium 回归通过。字段应用新增并发冲突拒绝。
旧窗口及集中工作区装配已移除；完整工作流驱动将在新会话面板接入时迁移至新宿主。

## 会话状态归属验证

`artifacts/m25/sessions-stop.json`：进程内与独立 Player 均完成三轮试玩面板重建，
同一会话对象和命令序号保持；忙时暂停、停止后旧异步结果忽略均通过。
两模式各 7 条命令终局及回放一致；停止后无帧、日志、忙碌状态残留，退出设备数为零。
SessionController 由必需基础插件管理 CPU 调度与会话生命周期，PlayPanel.Dispose 仅释放显示资源。

## Lua 插件验证

`artifacts/m25/scripts.json`：两种 Play 模式分别重载规则和 CPU，语法错误保留原状态及命令序号；
脚本面板重启不丢失文档文本，日志包含至少三版脚本并能重放到相同终局。
停止和面板停用后的异步结果通过会话代际及面板取消令牌隔离。既有 reload 回归通过。

## 视口生命周期验证

`artifacts/m25/viewports.json` 通过：布局插件三轮创建、窗口调整尺寸、缩放、输入取消及销毁；
每轮图形设备和原生子窗口计数均回到 0。编辑与试玩从同一视口服务创建 InteractiveTable。
补齐失焦／分离时释放自身鼠标捕获、取消输入，以及渲染缩放变化时更新相机并取消旧手势。
freecell-shortcuts、layouts、interaction、view 回归通过，空当接龙合法通关快捷操作保持有效。

## 调试面板验证

`artifacts/m25/debug-panels.json`：两种模式按各席位观察时不返回权威状态，显式全信息观察才返回；
关闭全信息后恢复普通席位投影。面板重建仍显示同一暂停会话，非法动作、CPU 单步与回放通过。
observer/timeline/debug-play/debug-external 回归通过；控制器同步当前观察身份与显式全信息标记。

## 导出工作流验证

`artifacts/m25/export-cards-verified/result.json` 通过：实际附加步骤执行、启停注销、
运行中导出及步骤所有者拒绝停用、缺失发行物诊断、目标目录保持不变。
修复 Avalonia 文本框延迟初始化事件覆盖目标目录的问题。
正式自包含 Player 重新发布为 Avalonia 12.1.1，导出核心测试通过；
`artifacts/m25/export-smoke.json` 从本次导出完成两局 GUI 游戏，无编辑器依赖。
预检验证 PE WindowsGui 子系统，正式启动不使用控制台入口。

## 预编译程序集与真实回收

`samples/Editor.SamplePlugin` 使用同一 Editor/Core、CordiSharp 和 Avalonia 合约，
实际 `AssemblyLoaderService` 加载可回收上下文；标准 UI 控件来自默认上下文，
扩展对象、事件、配置、后台任务及绘图回调随 CordiSharp fiber 清理。
`artifacts/m25/assemblies-drain.json` 通过三次加载/面板呈现/卸载/重新加载，
每次 WeakReference 确认加载上下文已回收，图形设备及原生窗口计数回到 0。
活动引用租约提前拒绝卸载；刻意保留扩展对象会报告强引用而不误报回收成功。
上游同步 GC 检查会阻塞 Avalonia 延迟清理，改为先请求卸载，再让 UI 队列完成工作，
在有限重试内检查真实回收；失败仍明确区分“功能已注销”与“程序集未回收”。

## 最终迁移核对

旧 PluginHost、PluginContext、IEditorPlugin 及其旧生命周期测试已删除；对应覆盖在 CordiTests
和真实 FoundationVerification 中执行。基础和可选插件共用 CordiSharp 注册/释放路径。
`artifacts/m25/foundation-final.json` 通过：仅基础插件即可持有文档并执行命令，
可选失败不破坏工作区；所有作者面板重建、草稿/Undo、保存重开、视口清理均通过。
解决方案构建及项目边界检查通过，新增边界禁止 CordiSharp 进入共享 Runtime/Player。
使用说明和开发契约在 docs/editor-guide.md、docs/editor-plugins.md；历史需求文件未修改。

## M2.5 最终回归

2026-10-06：解决方案 Release 构建 0 警告、0 错误；工程依赖边界检查通过。
`regression-final.log` 的 31 个默认测试组全部通过，另有正式发行物 export 组通过。
卡牌和六角各 20 固定种子的全 CPU 终局、重复运行及回放全部一致；
`artifacts/m25/cards-seeds.log`、`hex-seeds.log` 保存每个种子的结果。
`artifacts/m25/mode-gate.log` 与 `artifacts/m2-mode-gate/summary.json` 记录同一 40 种子
在进程内及独立 Player 的逐步帧、日志与回放一致性。
空当接龙 fresh seed 1 的 94 条合法通关命令、20 种子、快捷键/点击以及两种模式一致性通过。

本轮真实 Windows Sandbox 10.0.26100.0：hasDotnet=false、sdkFolder=false、editorInstalled=false。
`artifacts/m25/sandbox/{environment.json,cards-games.json,hex-games.json}`：两份 Avalonia 12.1.1
正式发行物各完成两局 GUI 游戏，退出码均为 0。验证后已停止本轮创建的沙箱。
通过 [微软 Sandbox CLI](https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/windows-sandbox/windows-sandbox-cli)
共享两个导出目录、以 ExistingLogin 执行验证；没有把本机去除 PATH 当作干净系统证据。

cua-driver 实际窗口检查发现并修复 Slot 的 object 数据模板吞掉标题和按钮文字的问题。
面板直接贡献 Control，注册的空模板必须不匹配任何普通数据；不得遮蔽后代字符串。
`editor-fixed.png`、`editor-play.png` 和 `foundation-rendered-final.json` 验证修复后标题、按钮与试玩区实际呈现。
原生视口的 UIA 子树有时不可遍历，截图仍可验证显示；本机未做多显卡或物理跨屏混合 DPI 人工检查。
核心 View 的缩放、输入取消、失焦和三轮设备归零验证已覆盖；保留既有 HWND airspace 限制。

程序集最终回归 `assemblies-final.json` 再次确认三次真实回收、故意保留对象诊断和设备归零。
修订 `scripts/validate-m2.ps1` 使用新的 foundation/session/export 验收入口，避免旧 --verify 入口失效。

`session-crash-fixed.json`：两模式规则/CPU 热重载及语法错误保留旧版本、三轮面板重建、
暂停/停止迟到结果、非法动作与回放通过；另外真实终止本轮启动的独立 Player，
控制器清除失效帧并给出诊断，再启动成功，最后图形设备归零。
操作拒绝/脚本校验失败仍保留会话；仅传输中断或已释放客户端清除失效会话。

## 整体审核：Standards

规范轴未发现 AGENTS.md / 领域及工单规范的硬性违反，发现三项生命周期问题：
1. 初始化超时后的清理与取消互相等待（P1）。已在释放前主动取消作用域，对初始化等待加取消边界，并拒绝迟到资源登记。
2. 导出临时目录删除失败导致 Running 未复位（P2）。已用嵌套 finally 保证复位，保留清理诊断。
3. 实际程序集 IAsyncPlugin 内层初始化仍可能无限等待（P1）。本阶段明确拒绝该入口；同步受控入口及 Effect 后台任务继续支持。

## 整体审核：Spec

需求轴发现三项：表单/组件草稿仅存控件或未计入脏状态（P1）；初始化取消等待环（P1）；
旧组件 YAML 无基线校验可能覆盖其他入口修改（P2）。均已修复，未发现越界功能。
表单现在存纯文本到文档，保留无效中间输入、Undo/Redo、取消离开；保存/试玩会列出未应用字段并拒绝继续。
组件/媒介/席位应用均检查配置基线，冲突保留草稿而不覆盖。

## 审核修复证据

- `review-core.log`：真实两次 15 秒初始化超时、协作取消、忽略取消后迟到注册拒绝、无关插件继续启停，以及文档/原型/媒介/布局核心组通过。
- `review-drafts-final.json`：真实席位、组件 YAML、未解析媒介字段重建恢复，字段 Undo/Redo、取消、保存阻止未应用输入和多入口冲突拒绝通过。
- `review-export/result.json`：附加步骤真实持有临时模块文件锁，清理失败仍结束导出状态，允许注销及继续预检。
- `review-assemblies.json`：永不返回的 IAsyncPlugin DLL 被装载器提前拒绝，无登记残留；同步示例三轮实际回收仍通过，强引用仍明确诊断，设备归零。
- 同时修复关闭保存失败时保留整个工作区、重复关闭只出现一次协调、快捷键别名规范化、运行中命令拒绝停用，以及 TextBox 延迟事件可能覆盖同步状态的问题。

审核计数：Standards 3 项、Spec 3 项（包含同一初始化问题）；全部已实施修复。

最终审核后再次运行 31 个默认测试组全部通过（`regression-reviewed.log`）。
`review-foundation-final.json` 额外覆盖快捷键别名冲突、文本焦点抑制、运行中命令保护及全部字段草稿行为；
`review-session-final.json` 再次完成两种模式的热重载、面板重建、实际 Player 故障恢复和设备归零。
卸载目录变更与停用置于同一个生命周期临界区，防止并发启用复活已卸载项；未知 ID 不创建孤立状态行。
最后的原子卸载/并发启用及孤立状态回归在 `review-lifecycle-final.log` 通过；
`review-assemblies-final.json` 仍为 success=true、devices=0。最终构建与依赖边界检查通过。
