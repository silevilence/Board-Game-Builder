# 扑克牌 UNO 展示验证记录

日期：2026-10-08。对应 ROADMAP「扑克牌 UNO：M4 完成后的总体功能展示」。

2026-10-09 更新：本机＋Hyper-V 虚拟机的独立 HTTPS 图形对局、双端重连与权威回放核对已通过；虚拟机无 SDK 的本地验证也已执行。用户已确认无控制台闪现与目标 DPI／窗口尺寸下的交互，全部验收门槛完成。详见 [跨机验证记录](hyperv-m4-uno-review.md)。下文早期结论按原验证日期理解。

实现及本机验收已完成；跨机联机和干净 Windows 人工验收未执行，保留两个顶层验收任务未勾选。没有以本机多进程或隔离 .NET 搜索路径代替这两个门槛。使用方式见 [扑克牌 UNO](../poker-uno.md)。

## 交付与边界

- `samples/poker-uno`：52 张普通扑克牌，4／5／6 人预设，规则与 CPU 均在 Lua 中。摸牌后仅能打出新摸到的牌或结束回合；耗尽时保留当前弃牌、隐藏回收其余弃牌并洗牌；连续整轮无牌可出且无牌可摸时平局。
- 通用引擎补充：PNG 区域引用 `resource#x,y,width,height`、定义文件预设、隐藏抽取、水平扇形布局和只显示堆顶；没有游戏名称或牌点数的宿主分支。
- 图形 Player 增加任意席位与全 CPU 设置、联机加入／恢复、公共观战及身份记录。联机只提交操作和消费投影，规则和 CPU 留在权威服务器。
- 协议版本升至 2：实际席位控制方式随帧作为独立元数据传递，不修改规则投影；旧协议客户端被明确拒绝，记录读取器仍兼容协议 1 的历史记录。
- Player 可依赖 Networking；Runtime 仍不依赖 Editor、Editor.Core 或 Avalonia 插件，服务器不依赖图形窗口。作者格式和打印沿用原有 CordiSharp 插件服务。
- 本地发行物：`artifacts/poker-uno/windows/Play.exe`、`game.bgm`；独立服务器：`artifacts/poker-uno/network-release/Server/Server.exe`。验证结果、截图、发行文件和测试凭据留在 Git 忽略的 `artifacts/poker-uno/`，不提交密钥。

## 自动化与图形证据

| 验证 | 结果及证据（相对于 artifacts/poker-uno） |
| --- | --- |
| Release 全解决方案构建 | `build-final.log`：0 警告、0 错误 |
| 常规回归 | `regression.log` 与 `regression-final.log` 合计 64 个不同测试组通过；后者重跑修改后的 UNO 本地模式、联机、身份、记录及其余回归 |
| 固定种子整局 | `batch-4/summary.json`、`batch-5/summary.json`、`batch-6/summary.json`：各 20 个种子，全部正常胜出、重跑一致、回放一致；步数分别为 30–111、36–130、48–135，上限 500 |
| 规则及错误边界 | `poker-uno`：非法出牌／越席不改变状态、52 张守恒、普通 J/Q/K、同色异花拒绝、摸牌后动作、回收不泄露顺序、阻塞平局、非法人数与区域、包／目录一致 |
| 各人数与控制配置 | `poker-uno-modes`：4／5／6 人，热座／分视角，全真人、混合 CPU、全 CPU 公共投影；图形设置覆盖全部预设、最后席位为唯一真人、取消不提交 |
| 真实 MonoGame 图集 | `gui-final.json`、`export-gui.json`：53 个不同区域、同一视口仅 1 张纹理；已查看 `.atlas.png` 和 `.6-players.png`，无邻牌串色／裁切，牌背及四花色普通牌正确 |
| 本地真实图形 | `export-gui.json`：4／5／6 人完整对局，6 人热座（20 次交接遮挡）及分视角完成，全 CPU 公共观战完成；退出后无残留图形设备 |
| 编辑器两种试玩 | `editor-session.json`：内嵌与外部 Player 均完成，命令数各 47，重载／暂停／单步／观察／回放通过，设备数归零 |
| 作者编辑与打印 | `poker-uno` 验证修改默认人数、Undo／Redo、保存与重开；`print` 验证按区域裁切输出、正面不同／背面一致及 PDF 生成 |
| 编辑器导出工作流 | `editor-export-final/result.json`：真实内置导出插件、预检、导出步骤生命周期、缺失依赖诊断、排除编辑器程序集，全部通过 |
| 独立服务进程 | `poker-uno-online`：4／5／6 人各完成，p1 为 CPU、两名真人、观众、真人及 CPU 回合重连、保存身份恢复、记录权限、人数指纹不匹配拒绝；过期本地操作不使连接掉线 |
| 导出包图形联机 | `online-gui-final/result.json`：已导出的 Play.exe 和自包含 Server.exe，两个玩家窗口与一个观众窗口完成；重连和图形回放通过，三个视口均有真实渲染（141／133／132 帧） |
| 自包含与 HTTPS | `https-release/result.json`：两个 CLI 客户端、HTTPS、自包含通过；`export-gui.json` 与图形联机同样使用空 DOTNET_ROOT／DOTNET_ROOT_X64、禁用多级查找，PATH 仅保留 Windows System32 |
| 既有图形示例 | `shell-regression.json`：FreeCell、群岛、基础卡牌的工具／游戏外壳、取消／非法设置、混合 CPU、重开及恢复均通过 |
| 工程依赖边界 | `scripts/check-boundaries.ps1` 通过；导出检查 PE 图形子系统、依赖完整性和排除编辑器程序集 |

首轮回归与发布并行时出现一次 CordiSharp 初始化／清理时序失败；停止并行发布后，未更改相关代码的重跑通过。随后协议版本升级使原测试硬编码的“错误版本 2”变为有效版本，已改为当前版本加一并额外覆盖旧版本 1 的拒绝，重跑通过。构建曾与运行中的测试争用 Windows DLL 文件锁，等待测试结束后构建成功。以上失败没有计入通过结果。

首次编辑器导出探针报告「Running export was unloaded」，未保留底层失败原因；探针补充同步失败诊断后重新构建，再次运行全部通过。没有修改导出工作流实现，不将这次重跑描述为已定位并修复原失败根因。

此次没有重复运行较长的 `m2-gate`／`m35-gate`；此前门槛见 [M4 验证记录](m4-review.md)。本次新增 UNO 的 60 种子门槛单独完整执行。图形验证使用实际窗口、视口和会话操作；不把它描述为人工鼠标完整走查或跨机器验证。

## M0～M4 能力覆盖

| 阶段 | 本示例入口与实际覆盖 | 限制／补充入口 |
| --- | --- | --- |
| M0 | Lua 规则、命令原子拒绝、隐藏投影、受控随机、CPU、整局与回放；规则测试及 60 种子批跑 | CPU 采用简单同花色保留策略，不宣称最优 |
| M1 | MonoGame 桌面、点选／拖拽合法牌、动作按钮、牌面、牌背、缩放适应；单图集共享纹理 | 图像 PNG 区域引用；不增加任意格式图集解析器 |
| M2 | 作者打开／修改／保存／重开、Undo／Redo、两种试玩、暂停／单步、身份观察、安全重载、记录；预编译 Player 导出 | 通过作者工作流展示，不为玩家增加调试操作；干净 Windows 尚待人工验收 |
| M2.5 | 复用现有 CordiSharp 编辑器贡献与作者格式，打印按图集区域裁切 | 未另建编辑器面板体系；插件生命周期由既有回归补充 |
| M3 | 4～6 人热座交接、同屏多投影、任意 CPU、全 CPU 观战；打印输出 | 不向基础玩法加入秘密提交、同时行动、拍卖或 WASM；由密封拍卖、WASM 示例及对应回归补充；图片／TTS 导入仅回归既有测试 |
| M3.5 | game.start.json、运行插件装配、人数定义预设、包指纹及快照、目录／包一致、Runtime 与 Editor 边界 | 第二定义格式由 alternative-definition 既有回归覆盖 |
| M4 | 图形玩家加入、权威 CPU、私有投影、序号校验、恢复、观众、本人记录；本机独立服务进程与图形导出完成对局 | 图形回路验证 HTTP 回环，HTTPS 由自包含传输验证覆盖；跨机网络及证书部署待人工验收 |

## 人工门槛完成记录

- [x] 至少两台机器运行导出的图形 Player，通过独立 HTTPS 服务器完成同一局，并分别断线重连；保留客户端结果与服务端生命周期记录。2026-10-09 按用户指定以本机＋Hyper-V 虚拟机通过，见跨机验证记录。
- [x] 干净 Windows（没有编辑器、开发 SDK）解压发行目录，完成本地及图形联机；人工确认启动、游玩、退出全程无控制台闪现，以及目标机器 DPI／窗口尺寸下的交互。2026-10-09 用户明确确认剩余人工项并要求勾选、提交。

2026-10-09 跨机门槛与干净 Windows 人工确认均通过，ROADMAP 的独立交付、总体展示验收及 M4 独立服务器项全部完成。

## TexturePacker JSON Hash 变更复验（2026-10-08）

后续需求将坐标串改为 `assets/cards.json` 的 JSON Hash。三份人数定义现直接引用 `card_hearts_A`、`card_back` 等名称；旧 `atlas-map.json` 已删除，PNG 通过 `meta.image` 自动进入资源快照、指纹和打包清单。上文坐标串验收属于初版历史证据；当前格式见 [运行时资源说明](../runtime-plugins.md)。

- `atlas-build.log`：Release 构建通过，0 警告、0 错误。
- `atlas-tests.log`：atlas、poker-uno、print、packages、modules、view、alternative-definition、runtime-entry、runtime-recording 共 9 组通过。覆盖目录／包／快照的帧名解析、PNG 自动收集、字段／路径／重名错误、旋转与裁剪还原，打印使用四色像素断言核对旋转方向与透明边位置。既有单图片及坐标串兼容。
- `texturepacker-gui.json`：真实 MonoGame 视口的 53 帧仍只使用 1 张纹理；4／5／6 人、热座、分视角、全 CPU 均完成，已查看全牌面截图。
- `texturepacker-editor.json`：内嵌／外部试玩通过，命令数各 47，释放后设备数 0。
- `texturepacker-publish.log`：更新的预编译 Player；最终导出目录 `windows-texturepacker-final/`，包中保留一张 PNG 和 JSON Hash，不拆分单牌图片。
- 生成脚本以固定帧名匹配牌面，不依赖 JSON 属性顺序，坐标输出整数；连续重新生成 JSON 字节相同。

玩法与网络协议未改，本轮不重复 60 种子整局及跨机测试；原人工门槛状态保持不变。
